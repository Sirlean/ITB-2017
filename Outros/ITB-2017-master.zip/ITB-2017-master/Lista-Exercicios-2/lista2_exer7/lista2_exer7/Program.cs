﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2_exer7
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaração de variável
            int n1 = 0;

        }
    }
}
